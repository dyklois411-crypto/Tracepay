# TracePay

Transaction Evidence & Reconciliation Infrastructure.

V1 is a dependency-free, mobile-first synthetic demo.
Pipeline: Ingest → Normalize → Order → Validate → Detect exception → Report.

Do not use real customer/payment data in this prototype.
