# API

Planned endpoint: `POST /v1/events`. Production requires authentication, validation, idempotency, signature verification, access controls and audit logging.
