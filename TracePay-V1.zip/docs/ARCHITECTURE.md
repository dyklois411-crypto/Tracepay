# Architecture

Provider adapters → ingestion → normalization → event store → timeline reconstruction → exception engine → investigation UI → evidence report.
